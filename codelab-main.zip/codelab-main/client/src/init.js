//init.js
window.global ||= window;
